function basil() {
  var a = document.getElementById("basilinfo");
  var b = document.getElementById("dandelioninfo");
  var c = document.getElementById("garlicinfo");
  var d = document.getElementById("gingerinfo");
  var e = document.getElementById("stjohnsinfo");
  var f = document.getElementById("turmericinfo");
  var g = document.getElementById("marigoldinfo");
  var h = document.getElementById("yarrowinfo");

  if (a.style.display === "none"){
    a.style.display = "block";
    b.style.display = "none";
    c.style.display = "none";
    d.style.display = "none";
    e.style.display = "none";
    f.style.display = "none";
    g.style.display = "none";
    h.style.display = "none";
  } else {
    a.style.display = "none";
  }

}; //basil text toggle

function ginger() {
  var a = document.getElementById("basilinfo");
  var b = document.getElementById("dandelioninfo");
  var c = document.getElementById("garlicinfo");
  var d = document.getElementById("gingerinfo");
  var e = document.getElementById("stjohnsinfo");
  var f = document.getElementById("turmericinfo");
  var g = document.getElementById("marigoldinfo");
  var h = document.getElementById("yarrowinfo");
  if (d.style.display === "none") {
      d.style.display = "block";
      a.style.display = "none";
      b.style.display = "none";
      c.style.display = "none";
      e.style.display = "none";
      f.style.display = "none";
      g.style.display = "none";
      h.style.display = "none";

  } else {
      d.style.display = "none";
  }
}; //ginger text toggle

function garlic() {
  var a = document.getElementById("basilinfo");
  var b = document.getElementById("dandelioninfo");
  var c = document.getElementById("garlicinfo");
  var d = document.getElementById("gingerinfo");
  var e = document.getElementById("stjohnsinfo");
  var f = document.getElementById("turmericinfo");
  var g = document.getElementById("marigoldinfo");
  var h = document.getElementById("yarrowinfo");

  if (c.style.display === "none") {
      c.style.display = "block";
      a.style.display = "none";
      b.style.display = "none";
      d.style.display = "none";
      e.style.display = "none";
      f.style.display = "none";
      g.style.display = "none";
      h.style.display = "none";
  } else {
      c.style.display = "none";
  }
}; //garlic text toggle



function dandelion() {
  var a = document.getElementById("basilinfo");
  var b = document.getElementById("dandelioninfo");
  var c = document.getElementById("garlicinfo");
  var d = document.getElementById("gingerinfo");
  var e = document.getElementById("stjohnsinfo");
  var f = document.getElementById("turmericinfo");
  var g = document.getElementById("marigoldinfo");
  var h = document.getElementById("yarrowinfo");

  if (b.style.display === "none") {
      c.style.display = "none";
      a.style.display = "none";
      b.style.display = "block";
      d.style.display = "none";
      e.style.display = "none";
      f.style.display = "none";
      g.style.display = "none";
      h.style.display = "none";
  } else {
      b.style.display = "none";
  }
}; //dandelion text toggle




function stjohns() {
  var a = document.getElementById("basilinfo");
  var b = document.getElementById("dandelioninfo");
  var c = document.getElementById("garlicinfo");
  var d = document.getElementById("gingerinfo");
  var e = document.getElementById("stjohnsinfo");
  var f = document.getElementById("turmericinfo");
  var g = document.getElementById("marigoldinfo");
  var h = document.getElementById("yarrowinfo");

  if (e.style.display === "none") {
      c.style.display = "none";
      a.style.display = "none";
      b.style.display = "none";
      d.style.display = "none";
      e.style.display = "block";
      f.style.display = "none";
      g.style.display = "none";
      h.style.display = "none";
  } else {
      e.style.display = "none";
  }
}; //st johns wort text toggle

function turmeric() {
  var a = document.getElementById("basilinfo");
  var b = document.getElementById("dandelioninfo");
  var c = document.getElementById("garlicinfo");
  var d = document.getElementById("gingerinfo");
  var e = document.getElementById("stjohnsinfo");
  var f = document.getElementById("turmericinfo");
  var g = document.getElementById("marigoldinfo");
  var h = document.getElementById("yarrowinfo");
  if (f.style.display === "none") {
      a.style.display = "none";
      b.style.display = "none";
      c.style.display = "none";
      d.style.display = "none";
      e.style.display = "none";
      f.style.display = "block";
      g.style.display = "none";
      h.style.display = "none";

  } else {
      f.style.display = "none";
  }
}; //turmeric text toggle

function marigold() {
  var a = document.getElementById("basilinfo");
  var b = document.getElementById("dandelioninfo");
  var c = document.getElementById("garlicinfo");
  var d = document.getElementById("gingerinfo");
  var e = document.getElementById("stjohnsinfo");
  var f = document.getElementById("turmericinfo");
  var g = document.getElementById("marigoldinfo");
  var h = document.getElementById("yarrowinfo");
  if (g.style.display === "none") {
      a.style.display = "none";
      b.style.display = "none";
      c.style.display = "none";
      d.style.display = "none";
      e.style.display = "none";
      f.style.display = "none";
      g.style.display = "block";
      h.style.display = "none";

  } else {
      g.style.display = "none";
  }
}; //marigold text toggle


function yarrow() {
  var a = document.getElementById("basilinfo");
  var b = document.getElementById("dandelioninfo");
  var c = document.getElementById("garlicinfo");
  var d = document.getElementById("gingerinfo");
  var e = document.getElementById("stjohnsinfo");
  var f = document.getElementById("turmericinfo");
  var g = document.getElementById("marigoldinfo");
  var h = document.getElementById("yarrowinfo");
  if (h.style.display === "none") {
      a.style.display = "none";
      b.style.display = "none";
      c.style.display = "none";
      d.style.display = "none";
      e.style.display = "none";
      f.style.display = "none";
      g.style.display = "none";
      h.style.display = "block";

  } else {
      h.style.display = "none";
  }
}; //yarrow text toggle
